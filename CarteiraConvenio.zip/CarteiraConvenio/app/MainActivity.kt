package br.com.portoseguro.carteiraconvenio

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import br.com.portoseguro.carteiraconvenio.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityMainBinding

    // Variáveis diferentes
    private var userName: String = "João"
    private var userAge: Int = 30
    private var isActive: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnFrase.setOnClickListener(this)  // Set OnClickListener para o botão
    }

    // Função para manipular a String
    private fun greetUser() {
        val greetingMessage = "Olá, $userName!"
        Toast.makeText(this, greetingMessage, Toast.LENGTH_SHORT).show()
    }

    // Função para manipular o Int
    private fun checkUserAge() {
        val ageMessage = if (userAge >= 18) {
            "Você é maior de idade."
        } else {
            "Você é menor de idade."
        }
        Toast.makeText(this, ageMessage, Toast.LENGTH_SHORT).show()
    }

    // Função para manipular o Boolean
    private fun checkUserStatus() {
        val statusMessage = if (isActive) {
            "Usuário ativo."
        } else {
            "Usuário inativo."
        }
        Toast.makeText(this, statusMessage, Toast.LENGTH_SHORT).show()
    }

    // Função chamada quando o botão for clicado
    override fun onClick(view: View?) {
        when (view?.id) {
            R.id.btn_frase -> {
                greetUser()       // Chama a função greetUser
                checkUserAge()    // Chama a função checkUserAge
                checkUserStatus() // Chama a função checkUserStatus
            }
            else -> {
                Toast.makeText(this, "Outro botão clicado", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
