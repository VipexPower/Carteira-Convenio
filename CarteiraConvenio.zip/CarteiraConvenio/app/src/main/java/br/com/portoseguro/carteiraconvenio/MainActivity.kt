package br.com.portoseguro.carteiraconvenio

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import br.com.portoseguro.carteiraconvenio.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityMainBinding

    private var userName: String = "João"
    private var userAge: Int = 30
    private var isActive: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnFrase.setOnClickListener(this)
    }


    private fun greetUser() {
        val greetingMessage = "Olá, $userName!"
        Toast.makeText(this, greetingMessage, Toast.LENGTH_SHORT).show()
    }

    private fun checkUserAge() {
        val ageMessage = if (userAge >= 18) {
            "Você é maior de idade."
        } else {
            "Você é menor de idade."
        }
        Toast.makeText(this, ageMessage, Toast.LENGTH_SHORT).show()
    }

    private fun checkUserStatus() {
        val statusMessage = if (isActive) {
            "Usuário ativo."
        } else {
            "Usuário inativo."
        }
        Toast.makeText(this, statusMessage, Toast.LENGTH_SHORT).show()
    }

    override fun onClick(view: View?) {
        when (view?.id) {
            R.id.btn_frase -> {
                greetUser()
                checkUserAge()
                checkUserStatus()
            }
            else -> {
                Toast.makeText(this, "Outro botão clicado", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
